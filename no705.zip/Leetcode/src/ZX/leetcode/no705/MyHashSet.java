package ZX.leetcode.no705;

import java.util.ArrayList;
import java.util.List;

public class MyHashSet { //利用数组下标index去存储值 该值是否存入 通过arr[index]==1 去判断！
	private int[] list;
	
	
	public MyHashSet() {
		list = new int[1000001];
		
	
    }
    
    public void add(int key) {
    	if(this.contains(key));
    	else {
    		this.list[key]=1;
    	}	
    }
    
    public void remove(int key) {
    	list[key] = 0;
    }
    
    /** Returns true if this set contains the specified element */
    public boolean contains(int key) {
    	return list[key]==1;
    }
    @Override
    public String toString() {
    	String str = "";
    	for(int i=0;i<this.list.length;i++) {
    		if(this.list[i]==1) str=str+i+" ";
    	}
    	return str;
    	
    }
    public static void main(String[] args) {
    	MyHashSet set = new MyHashSet();
    	set.add(1);
    	set.add(2);
    	set.add(2);
    	set.add(3);
    	set.add(3);
    	set.add(4);
    	System.out.println(set);
    	set.remove(2);
    	System.out.println(set);
    	
	}

}
