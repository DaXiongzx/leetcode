package ZX.leetcode.no331;

import java.util.Stack;

public class Solution {
	public static boolean isValidSerialization(String preorder) {  //树的出度等于入度，遍历到一个节点时，总出度应当大于总入度，因为还
		String []str = preorder.split(",");						//未遍历到该节点的子节点，因为根节点入度为0，所以需要先减去。 最终判断入度是否等于出度即可					
		int count = 1;
		for(int i=0;i<str.length;i++) {
			count --;
			if(count<0) return false;
			if(str[i].equals("#"));
			else 
				count+=2;
		}
		return count==0;
		
    }
//	public static boolean isValidSerialization(String preorder) {
//		boolean res = false;
//		String []str = preorder.split(",");
//		Stack<String> stack = new Stack<>();
//		for(int i=0;i<str.length;i++) {
//			stack.push(str[i]);
//			while(stack.size()>=3&&stack.get(stack.size()-1).equals("#")&&stack.get(stack.size()-2).equals("#")&&!(stack.get(stack.size()-3).equals("#"))) {
//				stack.pop();
//				stack.pop();
//				stack.pop();
//				stack.push("#");
//			}
//		}
//		
//		if(stack.size()==1&&stack.peek().equals("#")) res = true;
//		return res;
//    }
	public static void main(String[] args) {
		String preoder = "#,#,3,5,#" ; 
		System.out.println(isValidSerialization(preoder));
	}

}
