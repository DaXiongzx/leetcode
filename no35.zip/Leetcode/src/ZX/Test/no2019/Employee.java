package ZX.Test.no2019;

public class Employee {
	private String name;
	private int no;
	private int deptno;
	private String salary; //薪水
	private String comm; //加班工资
	
	
	public Employee(String name, int no, int deptno, String salary, String comm) {
		super();
		this.name = name;
		this.no = no;
		this.deptno = deptno;
		this.salary = salary;
		this.comm = comm;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getNo() {
		return no;
	}
	public void setNo(int no) {
		this.no = no;
	}
	public int getDeptno() {
		return deptno;
	}
	public void setDeptno(int deptno) {
		this.deptno = deptno;
	}
	public String getSalary() {
		return salary;
	}
	public void setSalary(String salary) {
		this.salary = salary;
	}
	public String getComm() {
		return comm;
	}
	public void setComm(String comm) {
		this.comm = comm;
	}
	

}
