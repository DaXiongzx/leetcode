package ZX.Test.no2019;

public class Programmer extends Employee{

	
	

}
