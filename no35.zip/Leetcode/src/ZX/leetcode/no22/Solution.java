package ZX.leetcode.no22;

import java.util.LinkedList;
import java.util.List;
import java.util.Stack;

public class Solution {
	public List<String> generateParenthesis(int n) {
		List<String> list = new LinkedList<>();
		Stack<Character> stack = new Stack<>();
		return list;

    }

}
