package ZX.leetcode.no13;

import java.util.HashMap;
import java.util.Map;

public class Solution {
	public static int romanToInt(String s) {
		int num = 0;
		Map<String,Integer> map = new HashMap<>();
		map.put("I",1);
		map.put("V",5);
		map.put("X",10);
		map.put("L",50);
		map.put("C",100);
		map.put("D",500);
		map.put("M",1000);
		int i = 0;
		for(i = 0;i<s.length();i++) {
			//System.out.println("num: "+num);
			if (i==s.length()-1)
				num+=map.get(String.valueOf(s.charAt(i)));	
			if(i < s.length()-1) {
				int first = map.get(String.valueOf(s.charAt(i)));
				int secend = map.get(String.valueOf(s.charAt(i+1)));
				//System.out.println("first: "+first+" "+"secend: "+secend);
				if(first < secend) {
					num = num+secend-first;
					
					i++;
				}
				else num +=first;
			}
		}
		
		return num;
    }
	public static void main(String[] args) {
		System.out.println(romanToInt("IV"));
	}

}
