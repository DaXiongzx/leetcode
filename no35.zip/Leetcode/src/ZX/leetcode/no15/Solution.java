package ZX.leetcode.no15;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class Solution {
	public static void printList(List list) {
		System.out.println("printList");
		Iterator<Integer> iterator = list.iterator();
		while(iterator.hasNext()) {
			System.out.print(iterator.next());
			System.out.print("---");
		}
	}
	
	public static boolean isSame(List list1,List list2) {
		boolean flag = true;
		for(int i=0;i<list1.size();i++) {
			int num = (int) list1.get(i);
			if(list2.contains(num)) {
				flag = true;
				continue;
			}
			else {
				flag = false;
				break;
			}
		}
		return flag;
	}
	public static List<List<Integer>> threeSum(int[] nums) {
		List<List<Integer>> reList = new LinkedList<List<Integer>>();
		if(nums.length<3) 
			return reList;
		
		for(int i=0;i<nums.length;i++) {
			for(int j=i+1;j<nums.length;j++) {
				for(int k=j+1;k<nums.length;k++) {
					if(nums[i]+nums[j]+nums[k]==0) {
						List<Integer> list = new LinkedList<>();
						list.add(nums[i]);
						list.add(nums[j]);
						list.add(nums[k]);
						reList.add(list);
					}
					
				}
				
			}
		}
		//System.out.println(reList);
		Map<List,Integer> map = new HashMap<>();
		for(int i=0;i<reList.size();i++) {
			map.put(reList.get(i), 1);
		}
		Set<List> set = new HashSet<>();
		set = map.keySet();
		reList.clear();
		for(List list:set) {
			reList.add(list);
		}
		//System.out.println("reList "+reList);
		for(int i=0;i<reList.size();i++) {
			for(int j=i+1;j<reList.size();j++) {
				if(isSame(reList.get(i), reList.get(j))) {
					reList.remove(j);
					j--;
				}
			}
		}
		//System.out.println("prere"+reList);
		return reList;

    }
	
	public static void main(String[] args) {
		int []nums = {-13,11,11,0,-5,-14,12,-11,-11,-14,-3,0,-3,12,-1,-9,-5,-13,9,-7,-2,9,-1,4,-6,-13,-7,10,10,9,7,13,5,4,-2,7,5,-13,11,10,-12,-14,-5,-8,13,2,-2,-14,4,-8,-6,-13,9,8,6,10,2,6,5,-10,0,-11,-12,12,8,-7,-4,-9,-13,-7,8,12,-14,10,-10,14,-3,3,-15,-14,3,-14,10,-11,1,1,14,-11,14,4,-6,-1,0,-11,-12,-14,-11,0,14,-9,0,7,-12,1,-6};
		System.out.println(threeSum(nums));
	}

}
