package ZX.leetcode.no1221;

import java.nio.charset.Charset;

public class Solution {
	public static int balancedStringSplit(String s) {
		int nums=0;
		int res = 0;
		int ans = 0;
		for(int i=0;i<s.length();i++) {
			nums = nums+(s.charAt(i)-'O');
			System.out.println("nums: "+nums);
			if(nums==0)
				res++;
		}
		System.out.println("res: "+res);
		return res;
    }
	
	public static void main(String[] args) {
		System.out.println(balancedStringSplit("RLRRLLRLRL"));
	}

}
