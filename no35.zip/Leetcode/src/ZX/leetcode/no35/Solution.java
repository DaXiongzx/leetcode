package ZX.leetcode.no35;

public class Solution {

	public static int searchInsert(int[] nums, int target) {
		int position = 0;
		int left = 0;
		int right = nums.length-1;
		int middle = (left+right)/2;
		while(left<=right) {
			middle = (left+right)/2;
			if(nums[middle]==target) {
				position = middle;
				return position;
			}
			else if(nums[middle]>target) {
				right = middle-1;
			}else {
				left = middle+1;
			} 
			
		}
		position = left;
		return position;

    }
	public static void main(String[] args) {
		int[] nums = {1,3,5,6};
		int target = 2;
		System.out.println(searchInsert(nums,target));
	}
	

}
