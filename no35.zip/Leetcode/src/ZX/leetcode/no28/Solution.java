package ZX.leetcode.no28;

public class Solution {
	public static int strStr(String haystack, String needle) {
		int flag = 1;
		int res = -1;
		int len = needle.length();
		if(haystack.equals("")&&needle.equals("")) return 0;
		for(int i=0;i<haystack.length()&&i+len-1<haystack.length();i++) {
//			System.out.println("i: "+i);
//			System.out.println("subStr: "+haystack.substring(i, i+len));
			if(haystack.substring(i, i+len).equals(needle)) {
				res = i;
				break;
			}	
		}
		return res;

    }
	public static void main(String[] args) {
		String haystack = "a";
		String needle = "a";
		//System.out.println(haystack.substring(0,2));
		System.out.println(strStr(haystack,needle));
		
	}

}
